 




 console.log(document.querySelector("#firstID").innerHTML);

 
 document.querySelector("#firstID").innerHTML = "Changed text"


 let answer = document.querySelector(".firstClass")
 console.log(answer.innerHTML)

 answer.innerHTML = 'This can be any text you want'