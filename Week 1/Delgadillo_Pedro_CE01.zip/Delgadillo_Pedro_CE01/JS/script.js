// This line of code displays a pop-up message to confirm that the JavaScript file is connected to the HTML document.
alert("My JavaScript file is connected properly!");

// This line of code outputs a message to the browser console.
console.log("I can display text in the Console!");
